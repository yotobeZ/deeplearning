train_results_root_folder = "/change_this_placeholder_folder" # For example "/Users/your-user/train-results"
trained_using_aws_spot_instance = False